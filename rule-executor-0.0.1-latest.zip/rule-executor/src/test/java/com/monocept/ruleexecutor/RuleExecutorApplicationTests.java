package com.monocept.ruleexecutor;

import org.junit.Ignore;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@Ignore
class RuleExecutorApplicationTests {

	@Test
	void contextLoads() {
		assert(true);
	}

}
