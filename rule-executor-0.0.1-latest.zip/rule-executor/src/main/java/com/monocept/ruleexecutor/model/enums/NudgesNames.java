package com.monocept.ruleexecutor.model.enums;

public enum NudgesNames {
    transaction_1,
    transaction_2,
    transaction_3,
    transaction_4,
    transaction_5,
}
