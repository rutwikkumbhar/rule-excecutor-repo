package com.monocept.ruleexecutor.model.enums;

public enum ThrottleLimitTypes {
    NO_OF_NUDGES_PER_DAY_PER_PERSON
}
