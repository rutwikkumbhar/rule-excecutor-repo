package com.monocept.ruleexecutor.model.enums;

public enum TemplateNames {

    TEMPLATE_1,
    TEMPLATE_2,
    TEMPLATE_3,
    TEMPLATE_4,
    TEMPLATE_5,
    TEMPLATE_6,
    TEMPLATE_7,
    TEMPLATE_8,
    TEMPLATE_9,
    TEMPLATE_10,
    TEMPLATE_11,

}
