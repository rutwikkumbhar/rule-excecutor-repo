package com.monocept.ruleexecutor.model.enums;

public enum DDupeCheckTypes {
    NUDGE_ID_SENDER,
    SENDER,
    NUDGE_ID
}
