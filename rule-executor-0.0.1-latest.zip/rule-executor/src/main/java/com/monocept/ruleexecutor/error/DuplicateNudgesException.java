package com.monocept.ruleexecutor.error;

public class DuplicateNudgesException extends RuntimeException{
    public DuplicateNudgesException(String message) {
        super(message);
    }
}
